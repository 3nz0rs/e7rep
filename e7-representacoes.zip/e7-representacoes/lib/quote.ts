import { SITE } from "./config";

export interface LinhaOrcamento {
  nome: string;
  categoria: string;
  marca: string;
  qtd: number;
}

export interface Contato {
  nome: string;
  empresa: string;
  cidade: string;
  obs: string;
}

export function montarMensagem(linhas: LinhaOrcamento[], contato: Contato): string {
  const itens = linhas.length
    ? linhas.map((l) => `- ${l.qtd}x ${l.nome} (${l.categoria} · ${l.marca})`).join("\n")
    : "- (itens a combinar)";

  let texto = `Olá! Gostaria de um orçamento dos itens abaixo:\n\n${itens}`;

  const obs = contato.obs.trim();
  if (obs) texto += `\n\nObservações: ${obs}`;

  const quem = [contato.nome, contato.empresa, contato.cidade]
    .map((parte) => parte.trim())
    .filter(Boolean)
    .join(" · ");
  if (quem) texto += `\n\n${quem}`;

  return texto;
}

export function urlWhatsapp(mensagem: string): string {
  return `https://wa.me/${SITE.whatsappNumero}?text=${encodeURIComponent(mensagem)}`;
}

export function urlGmail(mensagem: string, assunto = "Pedido de orçamento"): string {
  const params = [
    "view=cm",
    "fs=1",
    `to=${encodeURIComponent(SITE.email)}`,
    `su=${encodeURIComponent(assunto)}`,
    `body=${encodeURIComponent(mensagem)}`,
  ];
  return `https://mail.google.com/mail/?${params.join("&")}`;
}
