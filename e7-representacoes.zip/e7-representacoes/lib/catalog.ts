export type CategoriaId =
  | "lubrificantes"
  | "filtros"
  | "aco"
  | "dosadores"
  | "maravalha"
  | "cavaco"
  | "briquete";

export interface Categoria {
  id: CategoriaId;
  nome: string;
  /** Representada (marca) que fornece esta categoria. Aparece só na ficha do produto. */
  marca: string;
  descricao: string;
}

export interface Produto {
  slug: string;
  categoria: CategoriaId;
  nome: string;
  embalagem: string;
  aplicacao: string;
  especificacao: string;
  /** Caminho de uma imagem em /public, por exemplo "/produtos/oleo-15w40.webp". */
  imagem?: string;
}

export interface Representada {
  nome: string;
  segmento: string;
  categoria: CategoriaId | "todos";
  busca?: string;
}

export const CATEGORIAS: Categoria[] = [
  { id: "lubrificantes", nome: "Lubrificantes", marca: "Totaltec", descricao: "Óleos e graxas para frota, máquinas agrícolas e indústria." },
  { id: "filtros", nome: "Filtros", marca: "Totaltec", descricao: "Filtros de óleo, ar, combustível e hidráulico." },
  { id: "aco", nome: "Aço", marca: "Açostec", descricao: "Aço em geral: barras, chapas e tubos." },
  { id: "dosadores", nome: "Dosadores para aviário", marca: "Dosatron", descricao: "Dosagem de medicamento e vitaminas na água de bebida das aves." },
  { id: "maravalha", nome: "Maravalha", marca: "[Indústria de maravalha]", descricao: "Cama para aviário, equinos e granjas." },
  { id: "cavaco", nome: "Cavaco", marca: "[Indústria de cavaco]", descricao: "Para cama de aviário e para queima em caldeiras." },
  { id: "briquete", nome: "Briquete", marca: "[Indústria de briquete]", descricao: "Biomassa compactada para caldeiras, fornos e lareiras." },
];

export const REPRESENTADAS: Representada[] = [
  { nome: "Açostec", segmento: "Aço em geral", categoria: "todos", busca: "açostec" },
  { nome: "Dosatron", segmento: "Dosadores de medicamento na água, para aviários", categoria: "todos", busca: "dosatron" },
  { nome: "Totaltec", segmento: "Lubrificantes e filtros", categoria: "todos", busca: "totaltec" },
  { nome: "[Indústria de maravalha]", segmento: "Maravalha", categoria: "maravalha" },
  { nome: "[Indústria de cavaco]", segmento: "Cavaco", categoria: "cavaco" },
  { nome: "[Indústria de briquete]", segmento: "Briquete", categoria: "briquete" },
];

function slugify(texto: string): string {
  return texto
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

// [categoria, nome, embalagem, aplicação, especificação]
// Todos os itens abaixo são EXEMPLOS. Troque pelos produtos reais.
type Linha = [CategoriaId, string, string, string, string];

const LINHAS: Linha[] = [
  ["lubrificantes", "Óleo de motor 15W-40", "Balde 20 L · Tambor 200 L", "Motores diesel de frota e máquinas agrícolas", "SAE 15W-40 · nível de desempenho [conforme ficha do fabricante]"],
  ["lubrificantes", "Óleo hidráulico", "Balde 20 L · Tambor 200 L", "Sistemas hidráulicos de máquinas e prensas", "Grau ISO [conforme ficha do fabricante]"],
  ["lubrificantes", "Óleo de engrenagens", "Balde 20 L · Tambor 200 L", "Caixas de câmbio e redutores", "Grau [conforme ficha do fabricante]"],
  ["lubrificantes", "Graxa multiuso", "Balde 20 kg · Pote 1 kg", "Rolamentos, buchas e articulações", "Grau NLGI [conforme ficha do fabricante]"],
  ["filtros", "Filtro de óleo", "Unidade · caixa com [qtd]", "Motores de veículos e máquinas", "Código por aplicação [tabela de aplicação]"],
  ["filtros", "Filtro de ar", "Unidade · caixa com [qtd]", "Motores de veículos e máquinas", "Código por aplicação [tabela de aplicação]"],
  ["filtros", "Filtro de combustível", "Unidade · caixa com [qtd]", "Motores diesel e flex", "Código por aplicação [tabela de aplicação]"],
  ["filtros", "Filtro hidráulico", "Unidade · caixa com [qtd]", "Circuitos hidráulicos de máquinas", "Código por aplicação [tabela de aplicação]"],
  ["aco", "Barra chata", "Barra de [6 m, confirmar]", "Serralheria e estruturas", "Aço [especificação] · bitolas conforme tabela"],
  ["aco", "Vergalhão", "Barra de [12 m, confirmar]", "Construção civil", "Tipo [conforme tabela] · bitolas conforme tabela"],
  ["aco", "Chapa lisa", "Chapa [dimensões]", "Caldeiraria e fabricação", "Espessuras [conforme tabela]"],
  ["aco", "Tubo industrial", "Barra de [6 m, confirmar]", "Estruturas e máquinas", "Bitolas [conforme tabela]"],
  ["dosadores", "Dosador proporcional · modelo A", "Unidade", "Medicação e vitaminas na água de bebida de aviários", "Vazão e faixa de dosagem [conforme manual]"],
  ["dosadores", "Dosador proporcional · modelo B", "Unidade", "Medicação e vitaminas na água de bebida de aviários", "Vazão e faixa de dosagem [conforme manual]"],
  ["dosadores", "Kit de vedações para reposição", "Kit", "Manutenção do dosador", "Compatibilidade [modelos]"],
  ["dosadores", "Kit de instalação", "Kit", "Instalação na linha de água do aviário", "Itens do kit [lista]"],
  ["maravalha", "Maravalha fina", "Fardo comprimido [peso]", "Cama de aviário e baias", "Granulometria fina · umidade [conforme laudo]"],
  ["maravalha", "Maravalha média", "Fardo comprimido [peso]", "Cama de aviário e baias", "Granulometria média · umidade [conforme laudo]"],
  ["maravalha", "Maravalha para equinos", "Fardo comprimido [peso]", "Baias de cavalos", "Granulometria [conforme ficha]"],
  ["maravalha", "Maravalha a granel", "Carga fechada [m³]", "Granjas e grandes volumes", "Volume por carga [m³]"],
  ["cavaco", "Cavaco para cama de aviário", "Carga a granel [m³]", "Aviários de corte", "Umidade [conforme laudo]"],
  ["cavaco", "Cavaco para caldeira", "Carga a granel [m³]", "Geração de calor em caldeiras", "Umidade [conforme laudo]"],
  ["cavaco", "Cavaco classificado", "Carga a granel [m³]", "Usos que pedem granulometria padrão", "Granulometria [conforme ficha]"],
  ["cavaco", "Cavaco em big bag", "Big bag [peso]", "Armazenagem e transporte em menor volume", "Umidade [conforme laudo]"],
  ["briquete", "Briquete para caldeira e forno", "Pallet [kg]", "Caldeiras, fornos e secadores", "Poder calorífico [conforme laudo]"],
  ["briquete", "Briquete para lareira e churrasqueira", "Pacote ou caixa [kg]", "Uso doméstico e restaurantes", "Poder calorífico [conforme laudo]"],
  ["briquete", "Briquete a granel", "Carga fechada [kg]", "Indústrias de alto consumo", "Poder calorífico [conforme laudo]"],
  ["briquete", "Briquete em big bag", "Big bag [kg]", "Armazenagem e alimentação automática", "Poder calorífico [conforme laudo]"],
];

export const PRODUTOS: Produto[] = LINHAS.map(
  ([categoria, nome, embalagem, aplicacao, especificacao]) => ({
    slug: slugify(nome),
    categoria,
    nome,
    embalagem,
    aplicacao,
    especificacao,
  }),
);

export function ehCategoria(valor: string | null): valor is CategoriaId {
  return CATEGORIAS.some((c) => c.id === valor);
}

export function categoriaPorId(id: CategoriaId): Categoria {
  const categoria = CATEGORIAS.find((c) => c.id === id);
  if (!categoria) throw new Error(`Categoria desconhecida: ${id}`);
  return categoria;
}

export function produtoPorSlug(slug: string): Produto | undefined {
  return PRODUTOS.find((p) => p.slug === slug);
}

export function produtosDaCategoria(id: CategoriaId): Produto[] {
  return PRODUTOS.filter((p) => p.categoria === id);
}

export function normalizar(texto: string): string {
  return texto.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
}

export function buscarProdutos(
  lista: Produto[],
  categoria: CategoriaId | "todos",
  consulta: string,
): Produto[] {
  const q = normalizar(consulta.trim());
  return lista.filter((p) => {
    if (categoria !== "todos" && p.categoria !== categoria) return false;
    if (!q) return true;
    const cat = categoriaPorId(p.categoria);
    return normalizar(`${p.nome} ${cat.nome} ${cat.marca} ${p.aplicacao}`).includes(q);
  });
}

export function hrefDaRepresentada(r: Representada): string {
  if (r.busca) return `/catalogo?q=${encodeURIComponent(r.busca)}`;
  return `/catalogo?cat=${r.categoria}`;
}
