const urlDaVercel = process.env.VERCEL_PROJECT_PRODUCTION_URL;

export const SITE = {
  nome: "E7 Representações",
  descricao:
    "Aço, lubrificantes, filtros, dosadores para aviário, maravalha, cavaco e briquete em um só pedido. Representante comercial no Rio Grande do Sul.",
  representante: "Endrigo Michel da Silva",
  cargo: "Consultor de Vendas",
  area: "Rio Grande do Sul",
  // WhatsApp com 55 + DDD + número, sem espaços.
  whatsappNumero: "5551998352156",
  whatsappExibicao: "(51) 99835-2156",
  email: "emichel.vendas@gmail.com",
  url:
    process.env.NEXT_PUBLIC_SITE_URL ??
    (urlDaVercel ? `https://${urlDaVercel}` : "http://localhost:3000"),
} as const;
