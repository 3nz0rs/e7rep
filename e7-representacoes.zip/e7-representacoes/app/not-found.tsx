import Link from "next/link";

export default function NotFound() {
  return (
    <section className="block">
      <div className="wrap">
        <div className="head">
          <div className="eyebrow">Erro 404</div>
          <h2>Página não encontrada</h2>
          <p>O endereço pode ter mudado ou o produto saiu do catálogo.</p>
        </div>
        <div className="cta" style={{ marginTop: 0 }}>
          <Link className="btn btn-main" href="/catalogo">
            Ver catálogo
          </Link>
          <Link className="btn btn-line" href="/">
            Voltar ao início
          </Link>
        </div>
      </div>
    </section>
  );
}
