import Link from "next/link";
import { CATEGORIAS, PRODUTOS, produtosDaCategoria } from "@/lib/catalog";
import type { Produto } from "@/lib/catalog";
import { SITE } from "@/lib/config";
import { urlWhatsapp } from "@/lib/quote";
import { ProductCard } from "@/components/ProductCard";
import { Closing } from "@/components/Closing";

export default function Home() {
  // Um produto de cada categoria, para mostrar variedade logo na entrada.
  const destaques = CATEGORIAS.map((c) => PRODUTOS.find((p) => p.categoria === c.id))
    .filter((p): p is Produto => p !== undefined)
    .slice(0, 6);

  return (
    <>
      <div className="top on-black" style={{ borderBottom: 0 }}>
        <div className="wrap hero">
          <div>
            <div className="eyebrow">Representante comercial · {SITE.area}</div>
            <h1>
              Tudo para a granja e a indústria <em>em um só pedido</em>
            </h1>
            <p>
              Aço, lubrificantes, filtros, dosadores para aviário, maravalha, cavaco e briquete.
              Monte a lista e envie pelo WhatsApp ou pelo Gmail.
            </p>
            <div className="cta">
              <Link className="btn btn-main" href="/catalogo">
                Ver catálogo
              </Link>
              <a
                className="btn btn-ghost"
                href={urlWhatsapp("Olá! Vim pelo site e gostaria de um orçamento.")}
                target="_blank"
                rel="noopener noreferrer"
              >
                Falar no WhatsApp
              </a>
            </div>
          </div>
          <ol className="steps">
            <li>
              <b>1</b>
              <div>
                <strong>Escolha os produtos</strong>
                <span>Navegue por tipo: lubrificantes, aço, maravalha e mais.</span>
              </div>
            </li>
            <li>
              <b>2</b>
              <div>
                <strong>Monte a lista</strong>
                <span>Defina a quantidade de cada item e adicione observações.</span>
              </div>
            </li>
            <li>
              <b>3</b>
              <div>
                <strong>Envie o orçamento</strong>
                <span>Pelo WhatsApp ou pelo Gmail, com a lista já escrita.</span>
              </div>
            </li>
          </ol>
        </div>
        <div className="facts">
          <div className="wrap">
            <div className="fact">
              <b>7</b>
              <span>categorias de produto</span>
            </div>
            <div className="fact">
              <b>6</b>
              <span>indústrias representadas</span>
            </div>
            <div className="fact">
              <b>[00] anos</b>
              <span>de mercado (exemplo)</span>
            </div>
            <div className="fact">
              <b>{SITE.area}</b>
              <span>área de atendimento</span>
            </div>
          </div>
        </div>
      </div>

      <section className="block">
        <div className="wrap">
          <div className="head">
            <div className="eyebrow">Categorias</div>
            <h2>O que você procura</h2>
            <p>Escolha pelo tipo de produto. A indústria aparece na ficha de cada item.</p>
          </div>
          <div className="cats">
            {CATEGORIAS.map((c) => (
              <Link key={c.id} className="cat" href={`/catalogo?cat=${c.id}`}>
                <h3>{c.nome}</h3>
                <p>{c.descricao}</p>
                <span className="n">{produtosDaCategoria(c.id).length} produtos de exemplo</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="block band">
        <div className="wrap">
          <div className="head">
            <div className="eyebrow">Destaques</div>
            <h2>Mais pedidos (exemplo)</h2>
          </div>
          <div className="grid">
            {destaques.map((p) => (
              <ProductCard key={p.slug} produto={p} />
            ))}
          </div>
          <div className="more">
            <Link className="btn btn-line" href="/catalogo">
              Ver todos os produtos
            </Link>
          </div>
        </div>
      </section>

      <Closing />
    </>
  );
}
