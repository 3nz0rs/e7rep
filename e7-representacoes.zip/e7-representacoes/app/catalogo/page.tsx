import type { Metadata } from "next";
import { Suspense } from "react";
import { Catalog } from "@/components/Catalog";
import { Closing } from "@/components/Closing";

export const metadata: Metadata = {
  title: "Catálogo",
  description:
    "Lubrificantes, filtros, aço, dosadores para aviário, maravalha, cavaco e briquete. Busque, monte a lista e peça orçamento.",
};

export default function CatalogoPage() {
  return (
    <>
      <section className="block">
        <div className="wrap">
          <div className="head">
            <div className="eyebrow">Catálogo</div>
            <h2>Todos os produtos</h2>
            <p>
              Busque pelo nome, pela marca ou pela aplicação. A lista carrega aos poucos para a
              página abrir rápido.
            </p>
          </div>
          <Suspense fallback={null}>
            <Catalog />
          </Suspense>
        </div>
      </section>
      <Closing />
    </>
  );
}
