import type { Metadata } from "next";
import Link from "next/link";
import { REPRESENTADAS, hrefDaRepresentada } from "@/lib/catalog";
import { SITE } from "@/lib/config";
import { urlWhatsapp } from "@/lib/quote";
import { Closing } from "@/components/Closing";
import { OpenQuoteButton } from "@/components/OpenQuoteButton";

export const metadata: Metadata = {
  title: "Sobre",
  description: `${SITE.nome}: ${SITE.representante}, ${SITE.cargo}. Seis indústrias representadas e atendimento em todo o ${SITE.area}.`,
};

export default function SobrePage() {
  return (
    <>
      <div className="top on-black" style={{ borderBottom: 0 }}>
        <div className="wrap" style={{ paddingBlock: "44px 40px" }}>
          <div className="eyebrow">Sobre</div>
          <h1 style={{ fontSize: "clamp(40px, 8vw, 72px)", marginTop: 10 }}>
            Quem atende o seu pedido
          </h1>
        </div>
      </div>

      <section className="block">
        <div className="wrap about">
          <div className="portrait">
            <span>Foto do representante</span>
          </div>
          <div>
            <h2 style={{ fontSize: "clamp(30px, 5vw, 44px)", marginBottom: 4 }}>
              {SITE.representante}
            </h2>
            <div className="eyebrow" style={{ marginBottom: 16 }}>
              {SITE.cargo} · {SITE.nome}
            </div>
            <p>
              [Conte aqui a história: há quantos anos atua como representante comercial, como
              começou e em quais regiões já trabalhou.]
            </p>
            <p>
              A {SITE.nome} reúne seis indústrias que atendem granjas, oficinas, construtoras e
              indústrias em todo o {SITE.area}. Você fala com uma pessoa só e recebe tudo em um
              orçamento.
            </p>
            <p>
              [Espaço para um diferencial real: visita técnica, entrega própria, atendimento no
              mesmo dia, parceria de longa data com os clientes.]
            </p>
            <p className="note">
              WhatsApp {SITE.whatsappExibicao} · {SITE.email} · Atendimento em todo o {SITE.area}
            </p>
            <div className="cta" style={{ marginTop: 20 }}>
              <OpenQuoteButton>Pedir orçamento</OpenQuoteButton>
              <a
                className="btn btn-line"
                href={urlWhatsapp("Olá! Vim pelo site e gostaria de um orçamento.")}
                target="_blank"
                rel="noopener noreferrer"
              >
                Falar no WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="block band">
        <div className="wrap">
          <div className="head">
            <div className="eyebrow">Representadas</div>
            <h2>Indústrias que eu represento</h2>
            <p>Cada marca tem seus produtos e fichas técnicas no catálogo.</p>
          </div>
          <div className="brands">
            {REPRESENTADAS.map((r) => (
              <div className="brand-row" key={r.nome}>
                <h3>{r.nome}</h3>
                <p>{r.segmento}</p>
                <Link className="btn btn-line" href={hrefDaRepresentada(r)}>
                  Ver produtos
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="block">
        <div className="wrap">
          <div className="head">
            <div className="eyebrow">Como eu trabalho</div>
            <h2>Do pedido à entrega</h2>
          </div>
          <div className="how">
            <div>
              <h3>Você envia a lista</h3>
              <p>Pelo site, pelo WhatsApp ou pelo Gmail. Pode ser só uma ideia do que precisa.</p>
            </div>
            <div>
              <h3>Eu confiro com a indústria</h3>
              <p>Preço, estoque e prazo atualizados antes de responder. [definir prazo de resposta]</p>
            </div>
            <div>
              <h3>Entrega e acompanhamento</h3>
              <p>
                Acompanho o pedido até chegar e fico à disposição para dúvidas técnicas ou
                reposição.
              </p>
            </div>
          </div>
        </div>
      </section>

      <Closing />
    </>
  );
}
