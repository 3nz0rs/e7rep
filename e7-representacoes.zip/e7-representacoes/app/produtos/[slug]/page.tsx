import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PRODUTOS, categoriaPorId, produtoPorSlug, produtosDaCategoria } from "@/lib/catalog";
import { urlWhatsapp } from "@/lib/quote";
import { AddToQuote } from "@/components/AddToQuote";
import { Closing } from "@/components/Closing";
import { ProductCard } from "@/components/ProductCard";
import { ProductPhoto } from "@/components/ProductPhoto";

type Props = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return PRODUTOS.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const produto = produtoPorSlug(slug);
  if (!produto) return {};
  const categoria = categoriaPorId(produto.categoria);
  return {
    title: produto.nome,
    description: `${produto.nome} (${categoria.nome}, ${categoria.marca}). ${produto.aplicacao}. Peça orçamento pelo WhatsApp ou pelo Gmail.`,
  };
}

export default async function ProdutoPage({ params }: Props) {
  const { slug } = await params;
  const produto = produtoPorSlug(slug);
  if (!produto) notFound();

  const categoria = categoriaPorId(produto.categoria);
  const relacionados = produtosDaCategoria(produto.categoria)
    .filter((p) => p.slug !== produto.slug)
    .slice(0, 3);
  const duvida = urlWhatsapp(`Olá! Tenho uma dúvida sobre: ${produto.nome} (${categoria.marca}).`);

  return (
    <>
      <section className="block">
        <div className="wrap">
          <nav className="crumb" aria-label="Você está em">
            <Link href="/catalogo">Catálogo</Link> /{" "}
            <Link href={`/catalogo?cat=${categoria.id}`}>{categoria.nome}</Link> /{" "}
            <span>{produto.nome}</span>
          </nav>

          <div className="detail">
            <ProductPhoto produto={produto} prioridade />
            <div>
              <span className="tag">{categoria.nome}</span>
              <h1>{produto.nome}</h1>
              <div className="made">
                <b>Representada</b>
                <span>{categoria.marca}</span>
              </div>
              <p className="lead">
                {produto.aplicacao}. Valores e condições enviados junto com o orçamento.
              </p>
              <div className="price">Preço sob consulta</div>
              <div className="buy">
                <AddToQuote
                  slug={produto.slug}
                  nome={produto.nome}
                  rotulo="Adicionar ao orçamento"
                />
                <a className="btn btn-line" href={duvida} target="_blank" rel="noopener noreferrer">
                  Perguntar no WhatsApp
                </a>
              </div>
            </div>
          </div>

          <h2 className="sub">Ficha técnica</h2>
          <dl className="ficha">
            <div className="hl">
              <dt>Representada</dt>
              <dd>{categoria.marca}</dd>
            </div>
            <div>
              <dt>Categoria</dt>
              <dd>{categoria.nome}</dd>
            </div>
            <div>
              <dt>Embalagem</dt>
              <dd>{produto.embalagem}</dd>
            </div>
            <div>
              <dt>Aplicação</dt>
              <dd>{produto.aplicacao}</dd>
            </div>
            <div>
              <dt>Especificação</dt>
              <dd>{produto.especificacao}</dd>
            </div>
            <div>
              <dt>Código</dt>
              <dd>[SKU do fabricante]</dd>
            </div>
            <div>
              <dt>Disponibilidade</dt>
              <dd>Sob consulta</dd>
            </div>
          </dl>
          <div className="cta" style={{ marginTop: 14 }}>
            <button className="btn btn-line" type="button" disabled>
              Baixar ficha técnica em PDF
            </button>
          </div>
          <p className="note">
            O PDF de cada produto será ligado aqui quando os arquivos da indústria forem enviados.
            Os valores da tabela são exemplos.
          </p>

          {relacionados.length > 0 && (
            <>
              <h2 className="sub">Outros em {categoria.nome}</h2>
              <div className="grid">
                {relacionados.map((p) => (
                  <ProductCard key={p.slug} produto={p} />
                ))}
              </div>
            </>
          )}
        </div>
      </section>
      <Closing />
    </>
  );
}
