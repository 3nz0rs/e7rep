import type { MetadataRoute } from "next";
import { PRODUTOS } from "@/lib/catalog";
import { SITE } from "@/lib/config";

export default function sitemap(): MetadataRoute.Sitemap {
  const fixas = ["", "/catalogo", "/sobre"].map((caminho) => ({
    url: `${SITE.url}${caminho}`,
    changeFrequency: "monthly" as const,
  }));

  const produtos = PRODUTOS.map((p) => ({
    url: `${SITE.url}/produtos/${p.slug}`,
    changeFrequency: "monthly" as const,
  }));

  return [...fixas, ...produtos];
}
