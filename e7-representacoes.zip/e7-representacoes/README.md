# E7 Representações — site

Site de apoio às vendas da E7 Representações (Endrigo Michel da Silva, Consultor de Vendas), com atendimento em todo o Rio Grande do Sul.

Feito com **Next.js (App Router)** e **TypeScript**, pronto para publicar na **Vercel** a partir de um repositório no **GitHub**. Já inclui o **Vercel Analytics**.

## O que o site tem

- Início, Catálogo (busca, filtro por categoria e "mostrar mais"), ficha técnica de cada produto e página Sobre.
- Categorias por tipo de produto (Lubrificantes, Filtros, Aço, Dosadores para aviário, Maravalha, Cavaco e Briquete). A marca aparece na ficha do produto.
- Lista de orçamento que fica salva no navegador e envia a mensagem pronta por **WhatsApp** ou **Gmail**.
- `sitemap.xml`, `robots.txt` e títulos/descrições por página para o Google.

## Rodar no computador

Precisa do Node.js 20 ou mais novo.

```bash
npm install
npm run dev
```

Também funciona com yarn (`yarn` e `yarn dev`) ou pnpm (`pnpm i` e `pnpm dev`). Abra http://localhost:3000.

Para conferir o build de produção antes de publicar:

```bash
npm run build
npm run start
```

Depois do primeiro `npm install`, faça commit do arquivo `package-lock.json` (ou `yarn.lock` / `pnpm-lock.yaml`, conforme o gerenciador que você usar).

## Subir para o GitHub

```bash
git init
git add .
git commit -m "Primeira versão do site"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/e7-representacoes.git
git push -u origin main
```

O workflow em `.github/workflows/ci.yml` roda o build a cada push e pull request. Quando o `package-lock.json` estiver no repositório, troque `npm install` por `npm ci` no arquivo.

## Publicar na Vercel

1. Em vercel.com, clique em **Add New… → Project** e escolha o repositório do GitHub.
2. A Vercel reconhece o Next.js sozinha. Não precisa mudar nenhuma configuração.
3. (Opcional) Em **Settings → Environment Variables**, crie `NEXT_PUBLIC_SITE_URL` com o endereço final do site, por exemplo `https://www.seudominio.com.br`. Sem ela, o site usa o domínio de produção da Vercel.
4. Clique em **Deploy**. A cada push na branch `main`, a Vercel publica de novo.

## Vercel Analytics

O pacote já está no `package.json` e o componente já está no `app/layout.tsx`:

```tsx
import { Analytics } from "@vercel/analytics/next";
// ...
<Analytics />
```

Para instalar em outro projeto, use um destes comandos:

```bash
npm i @vercel/analytics
yarn add @vercel/analytics
pnpm i @vercel/analytics
```

Para começar a receber dados:

1. No painel da Vercel, abra o projeto, vá na aba **Analytics** e clique em **Enable**.
2. Publique de novo (um novo deploy ou um push).
3. Visite o site publicado. Os acessos aparecem no painel em alguns minutos.

O Analytics só envia dados no site publicado na Vercel, não no `npm run dev`.

## Como atualizar os produtos

Os produtos ficam em `lib/catalog.ts`, na lista `LINHAS`. Cada linha segue a ordem:

```
[categoria, nome, embalagem, aplicação, especificação]
```

- A página do produto e o `sitemap.xml` são criados sozinhos a partir dessa lista.
- Para colocar foto, salve o arquivo em `public/produtos/` (de preferência em WebP, com cerca de 800 px de largura) e acrescente o campo `imagem` ao produto, por exemplo `imagem: "/produtos/oleo-15w-40.webp"`. As fotos carregam só quando aparecem na tela.
- Marcas e categorias ficam na mesma pasta, nas listas `CATEGORIAS` e `REPRESENTADAS`.
- Telefone, e-mail e área de atendimento ficam em `lib/config.ts`.

## Estrutura

```
app/             páginas (início, catálogo, produtos/[slug], sobre), sitemap e robots
components/      cabeçalho, rodapé, catálogo, lista de orçamento e botões
lib/catalog.ts   categorias, marcas e produtos
lib/config.ts    dados da empresa e do contato
lib/quote.ts     mensagem do orçamento e links de WhatsApp e Gmail
public/produtos/ fotos dos produtos
```

## Pendências antes de publicar

- Trocar os 28 produtos de exemplo pelos reais, com fotos e fichas técnicas.
- Preencher os nomes das indústrias de maravalha, cavaco e briquete (hoje entre colchetes).
- Confirmar o nome da marca de lubrificantes e filtros (Totaltec).
- Preencher CNPJ, anos de mercado, foto e história na página Sobre.
- Ligar o PDF da ficha técnica em cada produto.
- Criar uma página de política de privacidade (LGPD) e linkar no rodapé.
