"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { PRODUTOS, categoriaPorId } from "@/lib/catalog";
import { montarMensagem, urlGmail, urlWhatsapp } from "@/lib/quote";
import type { Contato } from "@/lib/quote";
import { useQuote } from "./QuoteProvider";

export function QuoteBar() {
  const { itens, remover, limpar, aberto, abrir, fechar, aviso } = useQuote();
  const [contato, setContato] = useState<Contato>({ nome: "", empresa: "", cidade: "", obs: "" });
  const [avisoLocal, setAvisoLocal] = useState<string | null>(null);
  const areaRef = useRef<HTMLTextAreaElement>(null);

  const selecionados = useMemo(() => PRODUTOS.filter((p) => itens[p.slug] > 0), [itens]);
  const unidades = selecionados.reduce((soma, p) => soma + itens[p.slug], 0);

  const mensagem = useMemo(
    () =>
      montarMensagem(
        selecionados.map((p) => {
          const cat = categoriaPorId(p.categoria);
          return { nome: p.nome, categoria: cat.nome, marca: cat.marca, qtd: itens[p.slug] };
        }),
        contato,
      ),
    [selecionados, itens, contato],
  );

  useEffect(() => {
    if (!aberto) return;
    const aoTeclar = (e: KeyboardEvent) => {
      if (e.key === "Escape") fechar();
    };
    window.addEventListener("keydown", aoTeclar);
    return () => window.removeEventListener("keydown", aoTeclar);
  }, [aberto, fechar]);

  useEffect(() => {
    if (!avisoLocal) return;
    const t = window.setTimeout(() => setAvisoLocal(null), 2200);
    return () => window.clearTimeout(t);
  }, [avisoLocal]);

  async function copiar() {
    try {
      await navigator.clipboard.writeText(mensagem);
      setAvisoLocal("Mensagem copiada");
    } catch {
      areaRef.current?.focus();
      areaRef.current?.select();
      setAvisoLocal("Texto selecionado, copie com Ctrl+C");
    }
  }

  function campo(nome: keyof Contato, valor: string) {
    setContato((anterior) => ({ ...anterior, [nome]: valor }));
  }

  const toast = aviso ?? avisoLocal;

  return (
    <>
      <div className="bar">
        <div className="in">
          <div className="txt">
            Orçamento:{" "}
            <b>
              {selecionados.length} {selecionados.length === 1 ? "item" : "itens"}
              {unidades > 0 ? ` · ${unidades} un.` : ""}
            </b>
          </div>
          <div className="btns">
            <button className="btn btn-ghost" type="button" onClick={abrir}>
              Ver lista
            </button>
            <a
              className="btn btn-main"
              href={urlWhatsapp(mensagem)}
              target="_blank"
              rel="noopener noreferrer"
            >
              WhatsApp
            </a>
          </div>
        </div>
      </div>

      {aberto && (
        <div className="sheet" role="dialog" aria-label="Lista de orçamento">
          <div className="in">
            <h2>Sua lista de orçamento</h2>

            {selecionados.length > 0 ? (
              <ul className="lines">
                {selecionados.map((p) => (
                  <li key={p.slug}>
                    <span>
                      <strong>{p.nome}</strong> · {itens[p.slug]} un.
                    </span>
                    <button type="button" onClick={() => remover(p.slug)}>
                      Remover
                    </button>
                  </li>
                ))}
              </ul>
            ) : (
              <p style={{ color: "var(--muted)", margin: 0 }}>
                Nenhum item ainda. Adicione produtos no catálogo.
              </p>
            )}

            <div className="fields">
              <label htmlFor="f-nome">
                Nome
                <input
                  id="f-nome"
                  autoComplete="name"
                  placeholder="Seu nome"
                  value={contato.nome}
                  onChange={(e) => campo("nome", e.target.value)}
                />
              </label>
              <label htmlFor="f-emp">
                Empresa
                <input
                  id="f-emp"
                  autoComplete="organization"
                  placeholder="Nome da empresa"
                  value={contato.empresa}
                  onChange={(e) => campo("empresa", e.target.value)}
                />
              </label>
              <label htmlFor="f-cid">
                Cidade
                <input
                  id="f-cid"
                  placeholder="Cidade e estado"
                  value={contato.cidade}
                  onChange={(e) => campo("cidade", e.target.value)}
                />
              </label>
            </div>

            <label className="full" htmlFor="f-obs">
              Observações
              <textarea
                className="obs"
                id="f-obs"
                rows={2}
                placeholder="Ex.: embalagem, prazo de entrega, endereço"
                value={contato.obs}
                onChange={(e) => campo("obs", e.target.value)}
              />
            </label>

            <label className="full" htmlFor="msg">
              Mensagem que será enviada
            </label>
            <textarea className="msg" id="msg" ref={areaRef} readOnly value={mensagem} />

            <div className="row">
              <a
                className="btn btn-main"
                href={urlWhatsapp(mensagem)}
                target="_blank"
                rel="noopener noreferrer"
              >
                Enviar pelo WhatsApp
              </a>
              <a
                className="btn btn-main"
                href={urlGmail(mensagem)}
                target="_blank"
                rel="noopener noreferrer"
              >
                Enviar pelo Gmail
              </a>
            </div>
            <div className="row">
              <button className="btn btn-line" type="button" onClick={copiar}>
                Copiar mensagem
              </button>
              <button className="btn btn-line" type="button" onClick={limpar}>
                Limpar lista
              </button>
              <button className="btn btn-line" type="button" onClick={fechar}>
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && <div className="toast" role="status">{toast}</div>}
    </>
  );
}
