import Image from "next/image";
import type { Produto } from "@/lib/catalog";

export function ProductPhoto({
  produto,
  prioridade = false,
}: {
  produto: Produto;
  prioridade?: boolean;
}) {
  return (
    <div className="photo">
      {produto.imagem ? (
        <Image
          src={produto.imagem}
          alt={produto.nome}
          fill
          sizes="(max-width: 760px) 100vw, 360px"
          style={{ objectFit: "cover" }}
          priority={prioridade}
        />
      ) : (
        <span>Foto do produto</span>
      )}
    </div>
  );
}
