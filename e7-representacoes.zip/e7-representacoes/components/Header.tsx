"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { SITE } from "@/lib/config";

const LINKS = [
  { href: "/", rotulo: "Início" },
  { href: "/catalogo", rotulo: "Catálogo" },
  { href: "/sobre", rotulo: "Sobre" },
];

export function Header() {
  const caminho = usePathname() ?? "/";

  function ativo(href: string): boolean {
    if (href === "/") return caminho === "/";
    if (href === "/catalogo") {
      return caminho.startsWith("/catalogo") || caminho.startsWith("/produtos");
    }
    return caminho.startsWith(href);
  }

  return (
    <header className="top">
      <div className="wrap nav">
        <Link className="brand" href="/">
          <i aria-hidden="true" /> {SITE.nome}
        </Link>
        <nav aria-label="Principal">
          <ul>
            {LINKS.map((l) => (
              <li key={l.href}>
                <Link href={l.href} aria-current={ativo(l.href) ? "page" : undefined}>
                  {l.rotulo}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
}
