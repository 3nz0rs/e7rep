"use client";

import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { CATEGORIAS, PRODUTOS, buscarProdutos, ehCategoria } from "@/lib/catalog";
import type { CategoriaId } from "@/lib/catalog";
import { ProductCard } from "./ProductCard";

const POR_PAGINA = 12;

export function Catalog() {
  const params = useSearchParams();
  const catParam = params.get("cat");
  const qParam = params.get("q") ?? "";

  const [categoria, setCategoria] = useState<CategoriaId | "todos">(
    ehCategoria(catParam) ? catParam : "todos",
  );
  const [consulta, setConsulta] = useState(qParam);
  const [mostrados, setMostrados] = useState(POR_PAGINA);

  // Quando o endereço muda (por exemplo, vindo da página Sobre), acompanha os filtros.
  useEffect(() => {
    setCategoria(ehCategoria(catParam) ? catParam : "todos");
    setConsulta(qParam);
    setMostrados(POR_PAGINA);
  }, [catParam, qParam]);

  const lista = useMemo(
    () => buscarProdutos(PRODUTOS, categoria, consulta),
    [categoria, consulta],
  );
  const visiveis = lista.slice(0, mostrados);

  function escolher(id: CategoriaId | "todos") {
    setCategoria(id);
    setMostrados(POR_PAGINA);
  }

  return (
    <>
      <div className="tools">
        <input
          className="search"
          type="search"
          value={consulta}
          placeholder="Buscar: óleo, filtro, Totaltec, aviário…"
          aria-label="Buscar produtos"
          onChange={(e) => {
            setConsulta(e.target.value);
            setMostrados(POR_PAGINA);
          }}
        />
      </div>

      <div className="chips" role="group" aria-label="Categorias">
        <button
          type="button"
          className="chip"
          aria-pressed={categoria === "todos"}
          onClick={() => escolher("todos")}
        >
          Todos
        </button>
        {CATEGORIAS.map((c) => (
          <button
            key={c.id}
            type="button"
            className="chip"
            aria-pressed={categoria === c.id}
            onClick={() => escolher(c.id)}
          >
            {c.nome}
          </button>
        ))}
      </div>

      <div className="count">
        Mostrando {visiveis.length} de {lista.length}{" "}
        {lista.length === 1 ? "produto" : "produtos"}
      </div>

      {visiveis.length > 0 ? (
        <div className="grid">
          {visiveis.map((p) => (
            <ProductCard key={p.slug} produto={p} />
          ))}
        </div>
      ) : (
        <div className="empty-r">
          Nenhum produto encontrado. Tente outra palavra ou chame no WhatsApp.
        </div>
      )}

      {lista.length > visiveis.length && (
        <div className="more">
          <button
            className="btn btn-line"
            type="button"
            onClick={() => setMostrados((m) => m + POR_PAGINA)}
          >
            Mostrar mais ({lista.length - visiveis.length})
          </button>
        </div>
      )}
    </>
  );
}
