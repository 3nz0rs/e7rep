"use client";

import { useState } from "react";
import { useQuote } from "./QuoteProvider";

interface Props {
  slug: string;
  nome: string;
  rotulo?: string;
}

export function AddToQuote({ slug, nome, rotulo = "Adicionar" }: Props) {
  const { adicionar } = useQuote();
  const [qtd, setQtd] = useState("1");

  return (
    <>
      <input
        className="qty"
        type="number"
        min={1}
        value={qtd}
        onChange={(e) => setQtd(e.target.value)}
        aria-label={`Quantidade de ${nome}`}
      />
      <button
        className="btn btn-main"
        type="button"
        onClick={() => adicionar(slug, parseInt(qtd, 10))}
      >
        {rotulo}
      </button>
    </>
  );
}
