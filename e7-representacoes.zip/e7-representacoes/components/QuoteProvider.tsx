"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";

export type Itens = Record<string, number>;

interface QuoteContextValue {
  itens: Itens;
  adicionar: (slug: string, qtd: number) => void;
  remover: (slug: string) => void;
  limpar: () => void;
  aberto: boolean;
  abrir: () => void;
  fechar: () => void;
  aviso: string | null;
}

const STORAGE_KEY = "e7-orcamento";
const QuoteContext = createContext<QuoteContextValue | null>(null);

function lerItens(): Itens {
  try {
    const bruto = window.localStorage.getItem(STORAGE_KEY);
    if (!bruto) return {};
    const dados: unknown = JSON.parse(bruto);
    if (!dados || typeof dados !== "object") return {};
    const limpo: Itens = {};
    for (const [slug, qtd] of Object.entries(dados as Record<string, unknown>)) {
      if (typeof qtd === "number" && qtd > 0) limpo[slug] = Math.floor(qtd);
    }
    return limpo;
  } catch {
    return {};
  }
}

export function QuoteProvider({ children }: { children: ReactNode }) {
  const [itens, setItens] = useState<Itens>({});
  const [pronto, setPronto] = useState(false);
  const [aberto, setAberto] = useState(false);
  const [aviso, setAviso] = useState<string | null>(null);

  // Lê a lista salva no navegador depois que a página carrega.
  useEffect(() => {
    setItens(lerItens());
    setPronto(true);
  }, []);

  useEffect(() => {
    if (!pronto) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(itens));
    } catch {
      // armazenamento indisponível: a lista continua funcionando nesta visita
    }
  }, [itens, pronto]);

  useEffect(() => {
    if (!aviso) return;
    const t = window.setTimeout(() => setAviso(null), 2200);
    return () => window.clearTimeout(t);
  }, [aviso]);

  const adicionar = useCallback((slug: string, qtd: number) => {
    const n = Number.isFinite(qtd) && qtd > 0 ? Math.floor(qtd) : 1;
    setItens((anterior) => ({ ...anterior, [slug]: (anterior[slug] ?? 0) + n }));
    setAviso("Adicionado à lista");
  }, []);

  const remover = useCallback((slug: string) => {
    setItens((anterior) => {
      const copia = { ...anterior };
      delete copia[slug];
      return copia;
    });
  }, []);

  const limpar = useCallback(() => setItens({}), []);
  const abrir = useCallback(() => setAberto(true), []);
  const fechar = useCallback(() => setAberto(false), []);

  const valor = useMemo<QuoteContextValue>(
    () => ({ itens, adicionar, remover, limpar, aberto, abrir, fechar, aviso }),
    [itens, adicionar, remover, limpar, aberto, abrir, fechar, aviso],
  );

  return <QuoteContext.Provider value={valor}>{children}</QuoteContext.Provider>;
}

export function useQuote(): QuoteContextValue {
  const contexto = useContext(QuoteContext);
  if (!contexto) throw new Error("useQuote precisa estar dentro de <QuoteProvider>");
  return contexto;
}
