import Link from "next/link";
import { categoriaPorId } from "@/lib/catalog";
import type { Produto } from "@/lib/catalog";
import { AddToQuote } from "./AddToQuote";
import { ProductPhoto } from "./ProductPhoto";

export function ProductCard({ produto }: { produto: Produto }) {
  const categoria = categoriaPorId(produto.categoria);

  return (
    <article className="prod">
      <ProductPhoto produto={produto} />
      <div className="pbody">
        <span className="tag">{categoria.nome}</span>
        <h3>{produto.nome}</h3>
        <span className="spec">{produto.embalagem}</span>
        <div className="pfoot">
          <AddToQuote slug={produto.slug} nome={produto.nome} />
          <Link className="btn btn-line" href={`/produtos/${produto.slug}`}>
            Ver ficha
          </Link>
        </div>
      </div>
    </article>
  );
}
