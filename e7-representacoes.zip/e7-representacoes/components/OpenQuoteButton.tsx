"use client";

import type { ReactNode } from "react";
import { useQuote } from "./QuoteProvider";

export function OpenQuoteButton({
  children,
  className = "btn btn-main",
}: {
  children: ReactNode;
  className?: string;
}) {
  const { abrir } = useQuote();
  return (
    <button type="button" className={className} onClick={abrir}>
      {children}
    </button>
  );
}
