import { SITE } from "@/lib/config";

export function Footer() {
  return (
    <footer>
      <div className="wrap">
        © {SITE.nome} · {SITE.representante}, {SITE.cargo} · Atendimento em todo o{" "}
        {SITE.area} · [CNPJ] · WhatsApp {SITE.whatsappExibicao} · {SITE.email}
      </div>
    </footer>
  );
}
