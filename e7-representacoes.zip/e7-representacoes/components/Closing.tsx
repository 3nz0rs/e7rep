import { SITE } from "@/lib/config";
import { urlWhatsapp } from "@/lib/quote";
import { OpenQuoteButton } from "./OpenQuoteButton";

export function Closing() {
  return (
    <section className="closing">
      <div className="wrap">
        <div>
          <h2>Precisa de um orçamento?</h2>
          <p>
            Envie a lista pelo WhatsApp ou pelo Gmail. Respondo com valor, prazo e condição de
            pagamento.
          </p>
          <p>
            WhatsApp {SITE.whatsappExibicao} · {SITE.email}
          </p>
        </div>
        <div className="cta" style={{ margin: 0 }}>
          <OpenQuoteButton>Abrir minha lista</OpenQuoteButton>
          <a
            className="btn btn-ghost"
            href={urlWhatsapp("Olá! Vim pelo site e gostaria de um orçamento.")}
            target="_blank"
            rel="noopener noreferrer"
          >
            Falar no WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
